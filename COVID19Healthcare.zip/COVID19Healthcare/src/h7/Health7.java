/**
 * Restaurant7.java
 * jCOLIBRI2 framework. 
 * @author Juan A. Recio-Garc�a.
 * GAIA - Group for Artificial Intelligence Applications
 * http://gaia.fdi.ucm.es
 * 02/11/2007
 */
package h7;
import java.util.ArrayList;
import java.util.Collection;

import jcolibri.casebase.LinealCaseBase;
import jcolibri.cbraplications.StandardCBRApplication;
import jcolibri.cbrcore.Attribute;
import jcolibri.cbrcore.CBRCase;
import jcolibri.cbrcore.CBRCaseBase;
import jcolibri.cbrcore.CBRQuery;
import jcolibri.cbrcore.Connector;
import jcolibri.connector.DataBaseConnector;
import jcolibri.datatypes.Instance;
import jcolibri.exception.ExecutionException;
import jcolibri.exception.OntologyAccessException;
import jcolibri.method.retrieve.RetrievalResult;
import jcolibri.method.retrieve.NNretrieval.NNConfig;
import jcolibri.method.retrieve.NNretrieval.NNScoringMethod;
import jcolibri.method.retrieve.NNretrieval.similarity.global.Average;
import jcolibri.method.retrieve.NNretrieval.similarity.local.Equal;
import jcolibri.method.retrieve.NNretrieval.similarity.local.Interval;
import jcolibri.method.retrieve.NNretrieval.similarity.local.ontology.OntCosine;
import jcolibri.method.retrieve.selection.SelectCases;
import jcolibri.method.reuse.CombineQueryAndCasesMethod;
import jcolibri.method.reuse.NumericDirectProportionMethod;
import jcolibri.util.FileIO;
import es.ucm.fdi.gaia.ontobridge.OntoBridge;
import es.ucm.fdi.gaia.ontobridge.OntologyDocument;
import h7.AverageMultipleTextValues;
import h7.MedicalConnector;
import h7.ResultFrame;
import h7.TokensContained;

import java.util.Collection;

import jcolibri.casebase.LinealCaseBase;
import jcolibri.cbraplications.StandardCBRApplication;
import jcolibri.cbrcore.Attribute;
import jcolibri.cbrcore.CBRCase;
import jcolibri.cbrcore.CBRCaseBase;
import jcolibri.cbrcore.CBRQuery;
import jcolibri.cbrcore.Connector;
import jcolibri.exception.ExecutionException;
import jcolibri.extensions.textual.IE.opennlp.IETextOpenNLP;
import jcolibri.extensions.textual.lucene.LuceneIndex;
import jcolibri.method.retrieve.RetrievalResult;
import jcolibri.method.retrieve.NNretrieval.NNConfig;
import jcolibri.method.retrieve.NNretrieval.NNScoringMethod;
import jcolibri.method.retrieve.NNretrieval.similarity.global.Average;
import jcolibri.method.retrieve.NNretrieval.similarity.local.textual.LuceneTextSimilarity;
import jcolibri.method.retrieve.selection.SelectCases;
import jcolibri.extensions.recommendation.ContentBasedProfile.ObtainQueryFromProfile;
import jcolibri.extensions.textual.IE.common.BasicInformationExtractor;
import jcolibri.extensions.textual.IE.common.DomainTopicClassifier;
import jcolibri.extensions.textual.IE.common.FeaturesExtractor;
import jcolibri.extensions.textual.IE.common.GlossaryLinker;
import jcolibri.extensions.textual.IE.common.PhrasesExtractor;
import jcolibri.extensions.textual.IE.common.StopWordsDetector;
import jcolibri.extensions.textual.IE.common.TextStemmer;
//import jcolibri.extensions.textual.stemmer.Stemmer;
//import jcolibri.extensions.textual.lucene.*;
import jcolibri.extensions.textual.IE.common.ThesaurusLinker;
import jcolibri.extensions.textual.IE.opennlp.OpennlpMainNamesExtractor;
import jcolibri.extensions.textual.IE.opennlp.OpennlpPOStagger;
import jcolibri.extensions.textual.IE.opennlp.OpennlpSplitter;
//import jcolibri.method.retrieve.RetrievalResult;
//import jcolibri.method.retrieve.NNretrieval.NNConfig;
//import jcolibri.method.retrieve.NNretrieval.NNScoringMethod;
//import jcolibri.method.retrieve.NNretrieval.similarity.global.Average;
import jcolibri.method.retrieve.NNretrieval.similarity.local.Equal;
import jcolibri.method.retrieve.NNretrieval.similarity.local.textual.OverlapCoefficient;
//import jcolibri.method.retrieve.selection.SelectCases;
import jcolibri.test.main.SwingProgressBar;

/**
 * Single-Shot restaurants recommender using profiles, Nearest Neighbour retrieval and top k selection .
 * <br>
 * This is the typical recommender that obtains the user preferences from a profile, 
 * then computes Nearest Neigbour retrieval + top K selection, displays the retrieved
 * items and finishes.
 * <br>Summary:
 * <ul>
 * <li>Type: Single-Shot
 * <li>Case base: restaurants
 * <li>One off Preference Elicitation: Profile
 * <li>Retrieval:  Nearest Neighbour+ selectTopK
 * <li>Display: Custom window.
 * </ul>
 * This recommender implements the following template:<br>
 * <center><img src="../Template7_Cycle.jpg"/></center>
 * 
 * <br>Read the documentation of the recommenders extension for details about templates
 * and recommender strategies: {@link jcolibri.extensions.recommendation}
 * 
 * @see jcolibri.extensions.recommendation.ContentBasedProfile.ObtainQueryFromProfile
 * @see jcolibri.method.retrieve.NNretrieval.NNScoringMethod
 * @see jcolibri.method.retrieve.selection.SelectCases
 * 
 * @author Juan A. Recio-Garcia
 * @author Developed at University College Cork (Ireland) in collaboration with Derek Bridge.
 * @version 1.0
 *
 */
public class Health7 implements StandardCBRApplication
{
    Connector _connector;
    CBRCaseBase _caseBase;
LuceneIndex luceneIndex;
    
    /*
     * (non-Javadoc)
     * 
     * @see jcolibri.cbraplications.BasicCBRApplication#configure()
     */
    public void configure() throws ExecutionException
    {
	try
	{
	    //Use a custom connector
	    _connector = new MedicalConnector("/h7/medicine-large-v2.txt");
	    _caseBase = new LinealCaseBase();
	    
	    //To show the progress
	    jcolibri.util.ProgressController.clear();
	    SwingProgressBar pb = new SwingProgressBar();
	    jcolibri.util.ProgressController.register(pb);   
	} catch (Exception e)
	{
	    throw new ExecutionException(e);
	}
    }

    /*
     * (non-Javadoc)
     * 
     * @see jcolibri.cbraplications.StandardCBRApplication#preCycle()
     */
    public CBRCaseBase preCycle() throws ExecutionException
    {
    	_caseBase.init(_connector);

    	//Here we create the Lucene index
    	luceneIndex = jcolibri.method.precycle.LuceneIndexCreator.createLuceneIndex(_caseBase);
    	// Obtain a reference to OntoBridge
    			OntoBridge ob = jcolibri.util.OntoBridgeSingleton.getOntoBridge();
    			// Configure it to work with the Pellet reasoner
    			ob.initWithPelletReasoner();
    			// Setup the main ontology
    			OntologyDocument mainOnto = new OntologyDocument("http://gaia.fdi.ucm.es/ontologies/CovidRdf.owl", 
    					 	FileIO.findFile("h7/CovidRdf.owl").toExternalForm());
    			
    			// There are not subontologies
    		ArrayList<OntologyDocument> subOntologies = new ArrayList<OntologyDocument>();
    			// Load the ontology
    			ob.loadOntology(mainOnto, subOntologies, false);
    			
    	
	//In the precycle we pre-compute the information extraction in the case base
	
	//Initialize Wordnet
	/*ThesaurusLinker.loadWordNet();
	//Load user-specific glossary
	GlossaryLinker.loadGlossary("/rec7/glossary.txt");
	//Load phrases rules
	PhrasesExtractor.loadRules("/rec7/phrasesRules.txt");
	//Load features rules
	FeaturesExtractor.loadRules("/rec7/featuresRules.txt");
	//Load topic rules
	DomainTopicClassifier.loadRules("/rec7/domainRules.txt");
	
	//Obtain cases
	_caseBase.init(_connector);
	Collection<CBRCase> cases = _caseBase.getCases();

	//Perform IE methods in the cases
	
	//Organize cases into paragraphs, sentences and tokens
	OpennlpSplitter.split(cases);
	//Detect stopwords
	StopWordsDetector.detectStopWords(cases);
	//Stem text
	//TextStemmer.stem(cases);
	//Perform POS tagging
	OpennlpPOStagger.tag(cases);
	//Extract main names
	OpennlpMainNamesExtractor.extractMainNames(cases);
	//Extract phrases
	PhrasesExtractor.extractPhrases(cases);
	//Extract features
	FeaturesExtractor.extractFeatures(cases);
	//Classify with a topic
	DomainTopicClassifier.classifyWithTopic(cases);
	//Perform IE copying extracted features or phrases into other attributes of the case
	BasicInformationExtractor.extractInformation(cases);
	*/
	return _caseBase;
    }

    /*
     * (non-Javadoc)
     * 
     * @see jcolibri.cbraplications.StandardCBRApplication#cycle(jcolibri.cbrcore.CBRQuery)
     */
    public void cycle(CBRQuery query) throws ExecutionException
    {
	//query = ObtainQueryFromProfile.obtainQueryFromProfile( "/h7/profile.xml");
	
	Collection<CBRCase> cases = _caseBase.getCases();
	
	//Perform IE methods in the cases
	
	//Organize the query into paragraphs, sentences and tokens
	/*OpennlpSplitter.split(query);
	//Detect stopwords
	StopWordsDetector.detectStopWords(query);
	//Stem query
	//SpanishStemmerFilter.this(query);
	//TextStemmer.stem(query);
	//Perform POS tagging in the query
	OpennlpPOStagger.tag(query);
	//Extract main names
	OpennlpMainNamesExtractor.extractMainNames(query);
	
	//Now that we have the query we relate cases tokens with the query tokens
	//Using the user-defined glossary
	//GlossaryLinker.LinkWithGlossary(cases, query);
	//Using wordnet
	ThesaurusLinker.linkWithWordNet(cases, query);
	
	//Extract phrases
	PhrasesExtractor.extractPhrases(query);
	//Extract features
	FeaturesExtractor.extractFeatures(query);
	//Classify with a topic
	DomainTopicClassifier.classifyWithTopic(query);
	//Perform IE copying extracted features or phrases into other attributes of the query
	BasicInformationExtractor.extractInformation(query);
	
	//Now we configure the KNN method with some user-defined similarity measures
	NNConfig knnConfig = new NNConfig();
	knnConfig.setDescriptionSimFunction(new Average());
	
	knnConfig.addMapping(new Attribute("location", RestaurantDescription.class), new Equal());
	
	//To compare text we use the OverlapCofficient
	knnConfig.addMapping(new Attribute("description", RestaurantDescription.class), new OverlapCoefficient());
	//This function takes a string with several numerical values and computes the average
	knnConfig.addMapping(new Attribute("price", RestaurantDescription.class), new AverageMultipleTextValues(1000));
	//This function takes a string with several words separated by whitespaces, converts it to a set of tokens and
	//computes the size of the intersecction of the query set and the case set normalized with the case set
	knnConfig.addMapping(new Attribute("foodType", RestaurantDescription.class), new TokensContained());
	knnConfig.addMapping(new Attribute("food", RestaurantDescription.class), new TokensContained());
	knnConfig.addMapping(new Attribute("alcohol", RestaurantDescription.class), new Equal());
	knnConfig.addMapping(new Attribute("takeout", RestaurantDescription.class), new Equal());
	knnConfig.addMapping(new Attribute("delivery", RestaurantDescription.class), new Equal());
	knnConfig.addMapping(new Attribute("parking", RestaurantDescription.class), new Equal());
	knnConfig.addMapping(new Attribute("catering", RestaurantDescription.class), new Equal());
	
	System.out.println("RESULT:");
	
	Collection<RetrievalResult> res = NNScoringMethod.evaluateSimilarity(cases, query, knnConfig);
	res = SelectCases.selectTopKRR(res, 5);
	
	for(RetrievalResult rr: res)
	    System.out.println(rr);
	
	//Show the result
	RestaurantDescription qrd = (RestaurantDescription)query.getDescription();
	CBRCase mostSimilar = res.iterator().next().get_case();
	RestaurantDescription rrd = (RestaurantDescription)mostSimilar.getDescription();
	new ResultFrame(qrd.getDescription().toString(), rrd.getName(), rrd.getAddress(), rrd.getDescription().toString());
	
	*/
	NNConfig nnConfig = new NNConfig();
	nnConfig.setDescriptionSimFunction(new Average());
	
	
	//We only compare the "description" attribute using Lucene
	Attribute textualAttribute = new Attribute("description", MedicalDescription.class);
	nnConfig.addMapping(textualAttribute, new LuceneTextSimilarity(luceneIndex,query,textualAttribute, true));

	
	System.out.println("RESULT: ");
	
	Collection<RetrievalResult> res = NNScoringMethod.evaluateSimilarity(cases, query, nnConfig);
	res = SelectCases.selectTopKRR(res, 5);
	
	for(RetrievalResult rr: res)
	    System.out.println(rr);
	
	MedicalDescription qrd = (MedicalDescription)query.getDescription();
	CBRCase mostSimilar = res.iterator().next().get_case();
	MedicalDescription rrd = (MedicalDescription)mostSimilar.getDescription();
	new ResultFrame(qrd.getDescription().toString(), rrd.getDisease(), rrd.getTreatment(), rrd.getDescription().toString());
    }

    /*
     * (non-Javadoc)
     * 
     * @see jcolibri.cbraplications.StandardCBRApplication#postCycle()
     */
    public void postCycle() throws ExecutionException
    {
	//jcolibri.extensions.textual.wordnet.WordNetBridge.deInit();
	_connector.close();

    }
    
    public static void main(String[] args)
    {
	Health7 test = new Health7();
	try
	{
	    test.configure();
	    
	    CBRCaseBase caseBase = test.preCycle();
	   
	    System.out.println("CASE BASE: ");
	    for(CBRCase c: caseBase.getCases())
		System.out.println(c);
	    System.out.println("Total: "+caseBase.getCases().size()+" cases");

	    boolean _continue = true;
	    while(_continue)
	    {
        	    String queryString = javax.swing.JOptionPane.showInputDialog("Please enter the symptom description:");
        	    if(queryString == null)
        		_continue = false;
        	    else
        	    {	
                	    CBRQuery query = new CBRQuery();
                	    MedicalDescription queryDescription = new MedicalDescription();
                	    queryDescription.setDescription(new IETextOpenNLP(queryString));
                	    query.setDescription(queryDescription);
                	    
                	    test.cycle(query);
        	    }
	    }
         //   test.cycle(null);

	    test.postCycle();
	    
	} catch (ExecutionException e)
	{
	    org.apache.commons.logging.LogFactory.getLog(Health7.class).error(e);
	}
    }

}
