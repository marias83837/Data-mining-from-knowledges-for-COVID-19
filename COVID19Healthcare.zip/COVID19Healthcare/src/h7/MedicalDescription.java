/**
 * RestaurantDescription.java
 * jCOLIBRI2 framework. 
 * @author Juan A. Recio-Garc�a.
 * GAIA - Group for Artificial Intelligence Applications
 * http://gaia.fdi.ucm.es
 * 23/06/2007
 */
package h7;

import jcolibri.cbrcore.Attribute;
import jcolibri.cbrcore.CaseComponent;
import jcolibri.datatypes.Text;
import jcolibri.extensions.textual.IE.opennlp.IETextOpenNLP;

/**
 * Stores the description of a restaurant. <br>
 * Some attributes are loaded by the connector (name, address, location, phone and description). 
 * But the other ones are obtained (filled) by the Textual CBR methods applied to the description attribute.
 * 
 * @author Juan A. Recio-Garcia
 * @author Developed at University College Cork (Ireland) in collaboration with Derek Bridge.
 * @version 1.0
 * @see jcolibri.extensions.textual.IE.opennlp.IETextOpenNLP
 */
public class MedicalDescription implements CaseComponent
{
    String Disease;
    String Treatment;
    String location;
    String phone;
    IETextOpenNLP description;
    
    // Extracted values from the description
    String Age;
    String Bloodgroup;
    String BMI;
    String Gender;
    String Height;
    String Weight;
    Boolean Pregnancy;
    Boolean Smoke;
    String Residence;
    String MedicalHistory;
    String Occupation;
    
    /* (non-Javadoc)
     * @see jcolibri.cbrcore.CaseComponent#getIdAttribute()
     */
    public Attribute getIdAttribute()
    {
	return new Attribute("Disease",this.getClass());
    }

    /**
     * @return Returns the address.
     */
    public String getTreatment()
    {
        return Treatment;
    }

    /**
     * @param address The address to set.
     */
    public void setTreatment(String Treatment)
    {
        this.Treatment = Treatment;
    }

    /**
     * @return Returns the alcohol.
     */
    public Boolean getPregnancy()
    {
        return Pregnancy;
    }

    /**
     * @param alcohol The alcohol to set.
     */
    public void setPregnancy(Boolean Pregnancy)
    {
        this.Pregnancy = Pregnancy;
    }

    /**
     * @return Returns the breakfastDays.
     */
    public String getBMI()
    {
        return BMI;
    }

    /**
     * @param breakfastDays The breakfastDays to set.
     */
    public void setBMI(String BMI)
    {
        this.BMI = BMI;
    }

    /**
     * @return Returns the catering.
     */
    public String getOccupation()
    {
        return Occupation;
    }

    /**
     * @param catering The catering to set.
     */
    public void setOccupation(String Occupation)
    {
        this.Occupation = Occupation;
    }

    /**
     * @return Returns the delivery.
     */
    public String getResidence()
    {
        return Residence;
    }

    /**
     * @param delivery The delivery to set.
     */
    public void setResidence(String Residence)
    {
        this.Residence = Residence;
    }

    /**
     * @return Returns the description.
     */
    public Text getDescription()
    {
        return description;
    }

    /**
     * @param description The description to set.
     */
    public void setDescription(Text description)
    {
	if(description == null)
	    this.description = null;
	else
	    this.description = new IETextOpenNLP(description.toString());
    }
    


    /**
     * @return Returns the dinnerDays.
     */
    public String getHeight()
    {
        return Height;
    }

    /**
     * @param dinnerDays The dinnerDays to set.
     */
    public void setHeight(String Height)
    {
        this.Height = Height;
    }

    /**
     * @return Returns the food.
     */
    public String getWeight()
    {
        return Weight;
    }

    /**
     * @param food The food to set.
     */
    public void setWeight(String Weight)
    {
        this.Weight = Weight;
    }

    /**
     * @return Returns the foodType.
     */
    public String getBloodgroup()
    {
        return Bloodgroup;
    }

    /**
     * @param foodType The foodType to set.
     */
    public void setBloodgroup(String Bloodgroup)
    {
        this.Bloodgroup = Bloodgroup;
    }

    /**
     * @return Returns the location.
     */
    public String getLocation()
    {
        return location;
    }

    /**
     * @param location The location to set.
     */
    public void setLocation(String location)
    {
        this.location = location;
    }

    /**
     * @return Returns the lunchDays.
     */
    public String getGender()
    {
        return Gender;
    }

    /**
     * @param lunchDays The lunchDays to set.
     */
    public void setGender(String Gender)
    {
        this.Gender = Gender;
    }

    /**
     * @return Returns the name.
     */
    public String getDisease()
    {
        return Disease;
    }

    /**
     * @param name The name to set.
     */
    public void setDisease(String Disease)
    {
        this.Disease = Disease;
    }

    /**
     * @return Returns the parking.
     */
    public String getMedicalHistory()
    {
        return MedicalHistory;
    }

    /**
     * @param parking The parking to set.
     */
    public void setMedicalHistory(String MedicalHistory)
    {
        this.MedicalHistory = MedicalHistory;
    }

    /**
     * @return Returns the phone.
     */
    public String getPhone()
    {
        return phone;
    }

    /**
     * @param phone The phone to set.
     */
    public void setPhone(String phone)
    {
        this.phone = phone;
    }

    /**
     * @return Returns the price.
     */
    public String getAge()
    {
        return Age;
    }

    /**
     * @param price The price to set.
     */
    public void setAge(String Age)
    {
        this.Age = Age;
    }

    /**
     * @return Returns the takeout.
     */
    public Boolean getSmoke()
    {
        return Smoke;
    }

    /**
     * @param takeout The takeout to set.
     */
    public void setSmoke(Boolean Smoke)
    {
        this.Smoke = Smoke;
    }

    public String toString()
    {
	StringBuffer sb = new StringBuffer();
	sb.append(this.Disease);
	sb.append(", ");
	sb.append(this.Treatment);
	sb.append(", ");
	sb.append(this.location);
	sb.append(", ");
	sb.append(this.phone);
	sb.append(",");
	sb.append(this.description);
	
	return sb.toString();
    }
    
}
